import pandas as pd

# Path to the original dataset
file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\original data\Train_Test_IoT_Garage_Door.csv'

# Read the original dataset
df = pd.read_csv(file_path)

# Clean the 'date' and 'time' columns by removing any leading/trailing spaces
df['date'] = df['date'].str.strip()
df['time'] = df['time'].str.strip()

# Convert 'date' and 'time' columns to datetime and extract day, month, year, hour, minute, and second
df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'], format='%d-%b-%y %H:%M:%S', errors='coerce')

# Extracting components of the datetime
df['day'] = df['datetime'].dt.day
df['month'] = df['datetime'].dt.month
df['year'] = df['datetime'].dt.year
df['hour'] = df['datetime'].dt.hour
df['minute'] = df['datetime'].dt.minute
df['second'] = df['datetime'].dt.second

# Encode 'door_state' as a binary variable (0 for 'closed', 1 for 'open')
df['door_state_encoded'] = df['door_state'].apply(lambda x: 1 if x == 'open' else 0)

# One-hot encode the 'type' column to create binary columns for each attack type
df = pd.get_dummies(df, columns=['type'], prefix='type')

# Convert 'True'/'False' in the attack columns to 0 and 1
attack_columns = [col for col in df.columns if col.startswith('type_')]
df[attack_columns] = df[attack_columns].astype(int)

# Convert 'sphone_signal' to numeric, and then apply binary thresholding
df['sphone_signal'] = pd.to_numeric(df['sphone_signal'], errors='coerce')
df['sphone_signal_binary'] = df['sphone_signal'].apply(lambda x: 1 if x > 0 else 0)

# Drop the original 'door_state' and 'sphone_signal' columns as they are now redundant
df = df.drop(columns=['door_state', 'sphone_signal', 'datetime', 'date', 'time'])

# Save the processed dataset to a new file
processed_file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\processed data\Train_Test_IoT_Garage_Door_processed.csv'
df.to_csv(processed_file_path, index=False)

print("Processing complete. The processed dataset is saved at:", processed_file_path)
