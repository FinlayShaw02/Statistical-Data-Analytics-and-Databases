import pandas as pd

# Path to the original dataset
file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\original data\Train_Test_IoT_Fridge.csv'

# Read the original dataset
df = pd.read_csv(file_path)

# Step 1: Clean the 'date' and 'time' columns by removing any leading/trailing spaces
df['date'] = df['date'].str.strip()
df['time'] = df['time'].str.strip()

# Convert 'date' and 'time' columns to datetime with the correct format for a 2-digit year
df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'], format='%d-%b-%y %H:%M:%S', errors='coerce')

# Step 3: Check for rows where datetime conversion failed
invalid_rows = df[df['datetime'].isna()]
if not invalid_rows.empty:
    print("Warning: There are some invalid date/time rows that could not be parsed.")
    print(invalid_rows[['date', 'time']].head())

# Extract day, month, year, hour, minute, and second from the datetime column
df['day'] = df['datetime'].dt.day
df['month'] = df['datetime'].dt.month
df['year'] = df['datetime'].dt.year
df['hour'] = df['datetime'].dt.hour
df['minute'] = df['datetime'].dt.minute
df['second'] = df['datetime'].dt.second

# Encode 'temp_condition' as a binary variable (1 for high, 0 for low)
df['temp_condition_encoded'] = df['temp_condition'].apply(lambda x: 1 if x == 'high' else 0)

# Remove the original 'temp_condition' column since it's redundant now
df = df.drop(columns=['temp_condition'])

# One-hot encode the 'type' column to create binary columns for each type
df = pd.get_dummies(df, columns=['type'], prefix='type')

# Convert the one-hot encoded attack columns to binary (0 and 1) explicitly
attack_columns = [col for col in df.columns if col.startswith('type_')]
df[attack_columns] = df[attack_columns].astype(int)

# Capping 'fridge_temperature' at the 1st and 99th percentiles
lower_bound = df['fridge_temperature'].quantile(0.01)
upper_bound = df['fridge_temperature'].quantile(0.99)
df['fridge_temperature'] = df['fridge_temperature'].clip(lower=lower_bound, upper=upper_bound)

# Drop unnecessary columns like 'date', 'time', and 'datetime'
df = df.drop(columns=['date', 'time', 'datetime'])

# Step 9: Save the processed dataset to a new file
processed_file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\processed data\Train_Test_IoT_Fridge_processed.csv'
df.to_csv(processed_file_path, index=False)

print("Processing complete. The processed dataset is saved at:", processed_file_path)
