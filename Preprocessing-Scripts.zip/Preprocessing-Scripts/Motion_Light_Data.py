import pandas as pd

# Path to the original dataset
file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\original data\Train_Test_IoT_Motion_Light.csv'

# Read the original dataset
df = pd.read_csv(file_path)

# Clean the 'date' and 'time' columns by removing any leading/trailing spaces
df['date'] = df['date'].str.strip()
df['time'] = df['time'].str.strip()

# Convert 'date' and 'time' columns to datetime and extract day, month, year, hour, minute, and second
df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'], format='%d-%b-%y %H:%M:%S', errors='coerce')

# Extracting components of the datetime
df['day'] = df['datetime'].dt.day
df['month'] = df['datetime'].dt.month
df['year'] = df['datetime'].dt.year
df['hour'] = df['datetime'].dt.hour
df['minute'] = df['datetime'].dt.minute
df['second'] = df['datetime'].dt.second

# Clean and normalize 'light_status' values
df['light_status'] = df['light_status'].str.strip().str.lower()

# Encode 'light_status' as a binary variable (1 for 'on', 0 for 'off')
df['light_status_encoded'] = df['light_status'].apply(lambda x: 1 if x == 'on' else 0 if x == 'off' else None)

# One-hot encode the 'type' column to create binary columns for each attack type
df = pd.get_dummies(df, columns=['type'], prefix='type')

# Convert attack type columns from boolean (True/False) to binary (0/1)
attack_columns = [col for col in df.columns if col.startswith('type_')]
df[attack_columns] = df[attack_columns].astype(int)

# Drop unnecessary columns
df = df.drop(columns=['datetime', 'date', 'time', 'light_status'])

# Save the processed dataset to a new file
processed_file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\processed data\Train_Test_IoT_Motion_Light_processed.csv'
df.to_csv(processed_file_path, index=False)

print("Processing complete. The processed dataset is saved at:", processed_file_path)
