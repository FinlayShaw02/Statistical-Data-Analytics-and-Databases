import pandas as pd

# Path to the original dataset
file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\original data\Train_Test_IoT_Thermostat.csv'

# Read the original dataset
df = pd.read_csv(file_path)

# Clean the 'date' and 'time' columns by removing any leading/trailing spaces
df['date'] = df['date'].str.strip()
df['time'] = df['time'].str.strip()

# Convert 'date' and 'time' columns to datetime and extract day, month, year, hour, minute, and second
df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'], format='%d-%b-%y %H:%M:%S', errors='coerce')

# Extracting components of the datetime
df['day'] = df['datetime'].dt.day
df['month'] = df['datetime'].dt.month
df['year'] = df['datetime'].dt.year
df['hour'] = df['datetime'].dt.hour
df['minute'] = df['datetime'].dt.minute
df['second'] = df['datetime'].dt.second

# Apply 1st and 99th percentile capping for current_temperature
def cap_column(df, col_name):
    lower_bound = df[col_name].quantile(0.01)
    upper_bound = df[col_name].quantile(0.99)
    return df[col_name].clip(lower=lower_bound, upper=upper_bound)

df['current_temperature_capped'] = cap_column(df, 'current_temperature')

# One-hot encode the 'type' column to create binary columns for each attack type
df = pd.get_dummies(df, columns=['type'], prefix='type')

# Convert attack type columns from boolean (True/False) to binary (0/1)
attack_columns = [col for col in df.columns if col.startswith('type_')]
df[attack_columns] = df[attack_columns].astype(int)

# Drop the 'datetime', 'date', 'time', and original 'current_temperature' columns
df = df.drop(columns=['datetime', 'date', 'time', 'current_temperature'])

# Save the processed dataset to a new file
processed_file_path = r'C:\Users\shawj\Desktop\ALL\UNI\Masters\data\processed data\Train_Test_IoT_Thermostat_processed.csv'
df.to_csv(processed_file_path, index=False)

print("Processing complete. The processed dataset is saved at:", processed_file_path)
